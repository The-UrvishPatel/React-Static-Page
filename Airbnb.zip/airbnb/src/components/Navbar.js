import React from "react";
import logo from "../images/logo.png"

export default function Navbar () {

    // console.log({logo});
    // console.log(logo);

    return (
        
        <div className="logo-container">
            <img src={logo} alt="Logo" className="logo"/>
        </div>

    );

};