import React from "react";
import showcase from "../images/showcase.png"

export default function Navbar () {

    return (

        <div className="showcase-container">
            <img src={showcase} alt="Showcase"  className="showcase"/>
            <div className="desc">
                <h1>Online Experiences</h1>
                <h3>Join unique interactive activities led by one-of-a-kind hosts-all without leaving home.</h3>
            </div>
        </div>

    );

};