import React from "react";
import star from "../images/Star.png"

export default function Card (props) {

    // console.log(props)

    let status

    if(props.openSpots === "Soldout")
        status = "Soldout"
    else
        status = props.mode


    return (

        <div className="card-container">
        
            
            <div className="inner-card-container">
                <img src={props.img} alt="Photo"  className="photo"/>
                
                <div className="status-container"><span className="status">{status}</span></div>

                {/* {props.openSpots===0 && <span className="openSpots">Soldout</span> } */}

                <div className="rating-container">
                    <img src={star} alt="Star" className="star" />
                    <span>{props.rating}</span>
                    <span className="gray">({props.review})</span>
                    <span className="gray"> • {props.country}</span>
                </div>
                
                <p className="card-title">{props.title}</p>
                
                <p className="price">
                    <span className="bold">{"From $" + props.price + " "}</span>
                    <span>/ Person </span>
                </p>

            </div>
        
        </div>

    );

};