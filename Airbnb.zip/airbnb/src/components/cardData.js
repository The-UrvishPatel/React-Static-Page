import img1 from "../images/card1-image.png";
import img2 from "../images/card2-image.png";
import img3 from "../images/card3-image.png";

export default [

    {
        img : img1,
        rating : "5.0",
        review : 6,
        country : "USA",
        title : "Life Lessons with Katie Zaferes",
        price : 136,
        openSpots : "Soldout",
        mode: "Online"
    },

    {
        img : img2,
        rating : "5.0",
        review : 30,
        country : "USA",
        title : "Learn wedding photography",
        price : 125,
        openSpots : 1,
        mode: "Online"
    },

    {
        img : img3,
        rating : "4.8",
        review : 2,
        country : "USA",
        title : "Group Mountain Biking",
        price : 50,
        openSpots : 1,
        mode: "Offline"
    }

]