import React from "react";
import Navbar from "./components/Navbar";
import Showcase from "./components/Showcase";
import Card from "./components/Card";
import cardData from "./components/cardData"
// import img1 from "./images/card1-image.png";
// import img2 from "./images/card2-image.png";
// import img3 from "./images/card3-image.png";

 
export default function App() {

    const cards = cardData.map(data => {

        return (
            <Card 
                img = {data.img}
                rating = {data.rating}
                review = {data.review}
                country = {data.country}
                title = {data.title}
                price = {data.price}
                openSpots = {data.openSpots}
                mode = {data.mode}
            />
        );

    });

    console.log(cards);

    return (

        <div className="intro">
            <Navbar/>
            <Showcase/>

            <div className="all-card-container">
                
                {cards}
                
                {/* <Card
                    img = {img1}
                    rating = {"5.0"}
                    review = {6}
                    country = {"USA"}
                    title = {"Life Lessons with Katie Zaferes"}
                    price = {136}
                />

                <Card
                    img = {img2}
                    rating = {"5.0"}
                    review = {30}
                    country = {"USA"}
                    title = {"Learn wedding photography"}
                    price = {125}
                />
                
                <Card
                    img = {img3}
                    rating = {"4.8"}
                    review = {2}
                    country = {"USA"}
                    title = {"Group Mountain Biking"}
                    price = {50}
                /> */}
            </div>

        </div>
    );
};