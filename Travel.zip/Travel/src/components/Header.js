import React from "react";
import earth from "../images/earth.png"

export default function Header () {

    return (

        <div className="header-container">

            <img src={earth} alt="Earth" className="earth"/>
            <span className="travel-name">My Travel Journal | Urvish Patel</span>

        </div>
    )
}