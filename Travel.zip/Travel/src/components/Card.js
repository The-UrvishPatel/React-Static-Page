import React from "react";
import locationMark from "../images/locationMark.png"

export default function Card (props) {

    console.log(props)

    return (

        <div className="card-container">

            <img src={props.data.image} alt={props.data.location} className="card-image"/>

            <div className="card-content">

                <div className="location-info">

                    <img src={locationMark} alt="Location Mark" className="location-mark"/>
                    <span className="country-name">{props.data.country}</span>
                    <a href={props.data.link} className="link">View on Google Earth</a>

                </div>

                <span className="location-name">{props.data.location}</span>

                <span className="dates">{props.data.dates}</span>

                <p className="descptn">{props.data.descptn}</p>

            </div>

        </div>
    )
}