import mtFuji from "../images/mtFuji.png"
import geirangerfjord from "../images/geirangerfjord.png"
import opera from "../images/opera.png"

export default [

    {
        image: mtFuji,
        country: "JAPAN",
        link: "https://earth.google.com/web/@35.32519405,138.71339809,1728.40575008a,57779.36253397d,35y,33.06110475h,60.44372966t,0.00000001r/data=CkwaShJECiUweDYwMTk2MjlhNDJmZGM4OTk6MHhhNmExZmNjOTE2ZjNhNGRmGUtywK4mrkFAIUKIdfRJV2FAKgnlr4zlo6vlsbEYASAB",
        location: "Mount Fuji",
        dates: "12 Jan, 2021 - 24 Jan, 2021",
        descptn: "Mount Fuji is the tallest mountain in Japan, standing at 3,776 meters (12,380 feet). Mount Fuji is the single most popular tourist site in Japan, for both Japanese and foreign tourists.",
    },

    {
        image: opera,
        country: "AUSTRALIA",
        link: "https://earth.google.com/web/search/opera+house+near+Australia/@-33.85694797,151.21482349,31.72808254a,500.53560174d,35y,70.49251263h,44.36488988t,0r/data=CoUBGlsSVQolMHg2YjEyYWU2NjVlODkyZmRkOjB4MzEzM2Y4ZDc1YTFhYzI1MRmK3Hgcq-1AwCH5ree14-ZiQCoab3BlcmEgaG91c2UgbmVhciBBdXN0cmFsaWEYASABIiYKJAnM_7EjVEVCQBHfs99acmhBQBkEEIaUiYZhQCH6O8wEWT9hQA",
        location: "Sydney Opera House",
        dates: "27 May, 2021 - 8 Jun, 2021",
        descptn: "The Sydney Opera House is a multi-venue performing arts centre in Sydney. Located on the banks of the Sydney Harbour, it is often regarded as one of the 20th century's most famous and distinctive buildings",
    },

    {
        image: geirangerfjord,
        country: "NORWAY",
        link: "https://earth.google.com/web/search/Geiranger,+Norway/@62.0988054,7.20935135,45.26218744a,2184.31722408d,35y,0h,45t,0r/data=CnwaUhJMCiUweDQ2MTQyNjZkMGUzMTdjYzk6MHhlZTViNDA5MTlkM2Y3MzEzGU2_n3XoDE9AIebBJ-fV0hxAKhFHZWlyYW5nZXIsIE5vcndheRgBIAEiJgokCWXRob9D7UDAETbMIEXl7UDAGasF1hwH52JAIYoSQgrP5mJAKAI",
        location: "Geirangerfjord",
        dates: "01 Oct, 2021 - 18 Nov, 2021",
        descptn: "The Geiranger Fjord is a fjord in the Sunnmøre region of Møre og Romsdal county, Norway. It is located entirely in the Stranda Municipality.",
    }

]