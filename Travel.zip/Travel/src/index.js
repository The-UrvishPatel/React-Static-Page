import React from "react";
import ReactDOM from "react-dom";
import App from "./App"
import "./style.css"

// React.createElement(document.getElementById("root")).render(<App/>)
ReactDOM.render(<App/>, document.getElementById("root"))