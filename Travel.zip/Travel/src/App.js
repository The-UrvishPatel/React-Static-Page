import React from "react";
import Card from "./components/Card"
import Header from "./components/Header"
import cardData from "./components/cardData"


export default function App () {

    const cards = cardData.map(data => {

        return (
                
            < Card
                data = {data}
            />
        )
    })

    return (

        <div className="page">

            <Header />

            <div className="all-cards">
                {cards}
            </div>

        </div>

    )
}